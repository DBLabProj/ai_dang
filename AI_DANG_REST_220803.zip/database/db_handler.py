import pymysql
import configparser
import json
import datetime

# class Singleton(type):
#     _instances = {}
#     def __call__(cls, *args, **kwargs):
#         if cls not in cls._instances:
#             cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
#         else:
#             cls._instances[cls].__init__(*args, **kwargs)
 
#         return cls._instances[cls]

class DBHandler():
	
	def __init__(self):
		# parse 'config.ini' file automatically
		# please find 'config.ini' file or create it and place it in 'root' folder
		# and enter your mysql or mariadb connection information
		parser = configparser.ConfigParser()
		parser.read('config.ini')

		DB_props = parser["DATABASE"]
		DB_HOST = DB_props['HOST']
		DB_PORT = DB_props.getint('PORT')
		DB_NAME = DB_props['NAME']
		DB_USER = DB_props['USER']
		DB_PW = DB_props['PW']
		self.__conn = pymysql.connect(
						host=DB_HOST,
						port=DB_PORT,
						database=DB_NAME,
						user=DB_USER,
						password=DB_PW)

	def get_pred_no(self):
		cursor = self.__conn.cursor()
		sql = '''
			SELECT	concat(today_date, concat('-', serial_no)) as pred_no
			FROM	(SELECT	concat('P', date_format(now(), "%Y%m%d")) as today_date,
							right(concat('00', row_count + 1), 3) as serial_no
					FROM	(SELECT count(*) as row_count
							FROM	predict
							WHERE	date_format(datetime, '%Y%m%d') = date_format(now(), '%Y%m%d')) in_tb) out_tb
		'''
		
		cursor.execute(sql)
		sql_rs = cursor.fetchone()

		return sql_rs[0]

	def get_meal_no(self):
		cursor = self.__conn.cursor()
		sql = '''
			SELECT	concat(today_date, concat('-', serial_no)) as meal_no
			FROM	(SELECT	concat('M', date_format(now(), "%Y%m%d")) as today_date,
							right(concat('00', row_count + 1), 3) as serial_no
					FROM	(SELECT count(*) as row_count
							FROM	meal
							WHERE	date_format(datetime, '%Y%m%d') = date_format(now(), '%Y%m%d')) in_tb) out_tb
		'''
		
		cursor.execute(sql)
		sql_rs = cursor.fetchone()

		return sql_rs[0]

	def insert_pred(self, pred_no, result, img_path):
		cursor = self.__conn.cursor()
		sql = '''
			INSERT INTO predict VALUES(%s, %s, %s, %s)
		'''
		now = datetime.datetime.now()

		try:
			cursor.execute(sql, (pred_no, now, result, img_path))
		except pymysql.err.DataError as e:
			print(e)
			return False
		
		self.__conn.commit()

		return True
	

	def insert_meal(self, no, user, amount, pred_no, desc):
		cursor = self.__conn.cursor()
		sql = 'INSERT INTO meal VALUES(%s, %s, %s, %s, %s, %s)'
		now = datetime.datetime.now()

		try:
			cursor.execute(sql, (no, now, user, amount, pred_no, desc))
		except pymysql.err.DataError as e:
			print(e)
			return False
		
		self.__conn.commit()

		return True
		
	# food_name, serving_size, unit, energy, protein, fat, carbohydrate, total_sugar, salt, cholesterol
	def insert_food_info(self, data):
		cursor = self.__conn.cursor()
		sql = 'INSERT INTO food_info VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)'
		try:
			cursor.executemany(sql, data)
		except pymysql.err.DataError as e:
			print(e)
			return False
		
		self.__conn.commit()
		return True


	def close(self):
		self.__conn.close()