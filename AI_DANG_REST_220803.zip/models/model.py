import torch
from torch import nn
from torchvision import models, transforms

import io
from PIL import Image
class ClassifyFood:

    __class_names = ['전복, 참전복, 생것', '아포가토', '비빔밥', '양배추, 생것', '케이크', '캘리포니아롤', '카라멜마끼아또', '치즈볼',
        '치즈피자', '치킨카레', '초콜릿', '코코아', '카페모카', '콤비네이션 피자', '크림파스타', '오이 샐러드',
        '컵라면', '카레 소스', '찐빵', '어묵우동', '낙지쭈꾸미볶음', '고추', '소갈비구이', '연어구이',
        '잼빵', '액상 요구르트', '잡곡빵', '오트밀', '오믈렛', '오므라이스', '오렌지', '오븐구이치킨',
        '양배추절임', '잣', '팥', '팥죽', '생맥주', '양상추샐러드', '스크램블에그', '양념치킨',
        '참깨', '슈크림', '송편(깨)', '순대국밥', '스파게티면', '춘권', '안심스테이크', '된장찌개', '찜닭',
        '타코야끼', '토마토스파게티소스', '야채주스', '비엔나 소시지', '야끼소바']
    

    __device = 'cuda' if torch.cuda.is_available() else 'cpu'

    def __init__(self):

        # resnext 모델 불러오기
        model = models.resnext50_32x4d(pretrained=False)
        num_ftrs = model.fc.in_features
        
        # output값 class개수로 맞춰주기
        model.fc = nn.Linear(num_ftrs, len(self.__class_names))
        model = model.to(self.__device)

        # 학습된 모델 가져오기
        pre = torch.load('./models/model_state_dict.pt', map_location=self.__device)
        model.load_state_dict(pre)

        # 모델 추론모드로 변경
        model.eval()
        # 모델 저장
        self.__model = model

    # 이미지 전처리
    def __transform_image(self, image_bytes):
        my_transforms = transforms.Compose([transforms.Resize(255),
                                            transforms.CenterCrop(224),
                                            transforms.ToTensor(),
                                            transforms.Normalize(
                                                [0.485, 0.456, 0.406],
                                                [0.229, 0.224, 0.225])])
        image = Image.open(io.BytesIO(image_bytes))
        return my_transforms(image).unsqueeze(0)

    # 이미지 추론
    def predict(self, image_bytes):
        input = self.__transform_image(image_bytes=image_bytes)
        input = input.to(self.__device)
        input_parameter = next(self.__model.parameters())
        # 이미지 추론하기
        outputs = self.__model(input)
        _, output = torch.max(outputs, 1)

        # sorted_opts = torch.sort(outputs)
        
        # for tensor_elm in sorted_opts[1][0]:
        #     idx = tensor_elm.item()
        #     print(self.__class_names[idx])

        output_idx = output.item()
        return self.__class_names[output_idx]

    def get_classes(self):
        return self.__class_names
    