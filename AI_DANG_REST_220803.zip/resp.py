
import requests

f = open('./samples/test2.jpg','rb')
resp = requests.post("http://localhost:5000/predict", files={"file": f.read()})
print(resp.json())