from flask import Flask, jsonify, request, render_template
from database.db_handler import DBHandler
from models.model import ClassifyFood
import os
from PIL import Image
import numpy as np

app = Flask(__name__)
model = ClassifyFood()

#image rename in board
cnt = 1

@app.route('/sample')
def sample():
    return render_template('sample.html', classes=model.get_classes())

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        basewidth = 480

        file = request.files['file']
        
        img_bytes = file.read()
        class_name = model.predict(img_bytes)
        db = DBHandler()
        pred_no = db.get_pred_no()
        img_path = f'./static/images/{pred_no}.jpg'
        
        image = Image.open(file)
        print(np.array(image).shape)
        wpercent = (basewidth/float(image.size[0]))
        hsize = int((float(image.size[1])*float(wpercent)))
        image = image.resize((basewidth,hsize), Image.ANTIALIAS)

        image.save(img_path)

        _, img_name = os.path.split(img_path)
        db.insert_pred(pred_no, class_name, img_name)
        db.close()
        return jsonify({'predict_no': pred_no, 'class_name': class_name})
    
@app.route('/uploadImage', methods=['POST'])
def uploadImage():
    global cnt
    if request.method == 'POST':
        file = request.files['file']
        db = DBHandler()
        img_name = 'image' + str(cnt)
        img_path = f'./static/images/{img_name}.jpg'
        image = Image.open(file)
        
        print(img_path)
        
        image.save(img_path)
        cnt += 1
        
        db.close()

        return jsonify({'img_name': img_name})


@app.route('/add_meal', methods=['POST'])
def add_meal():
    if request.method == 'POST':
        user = request.form['user']
        amount = request.form['amount']
        pred_no = request.form['pred_no']
        desc = request.form['desc']
        
        db = DBHandler()
        no = db.get_meal_no()
        db.insert_meal(no, user, amount, pred_no, desc)
        db.close()
        return jsonify({'meal_no': no})

app.run(host='0.0.0.0', debug=True)